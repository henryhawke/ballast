export const grants = [
  "member",
  "create_company",
  "edit_company",
  "delete_company",
  "read_company",
  "delete_task",
  "create_task",
];

export default grants;
