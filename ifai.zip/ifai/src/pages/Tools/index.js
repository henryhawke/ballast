/* eslint-disable no-unused-vars */
/* eslint-disable no-lone-blocks */

/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable no-console */
// import _, { map } from "underscore";

import React, { useState, useEffect, useRef } from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import { useHistory } from "react-router-dom";
import { format } from "date-fns";
import TextField from "@material-ui/core/TextField";
import ReactMarkdown from "react-markdown";
import Scrollbar from "material-ui-shell/lib/components/Scrollbar";
import Calculations from "../../algorithms/Calculations";
import { useAuth } from "base-shell/lib/providers/Auth/";
// import { Link } from 'react-router-dom'
import Paper from "@material-ui/core/Paper";
import { injectIntl } from "react-intl";
import Page from "material-ui-shell/lib/containers/Page/Page";
import { useFirebase } from "rmw-shell/lib/providers/Firebase";
import { makeStyles } from "@material-ui/core/styles";
import clsx from "clsx";
import moment from "moment";
import Typography from "@material-ui/core/Typography";
import Fab from "@material-ui/core/Fab";
import CircularProgress from "@material-ui/core/CircularProgress";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";

import Switch from "@material-ui/core/Switch";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogActions from "@material-ui/core/DialogActions";
import Slide from "@material-ui/core/Slide";
import { DataGrid } from "@material-ui/data-grid";
import IconButton from "@material-ui/core/IconButton";
import CloseIcon from "@material-ui/icons/Close";
import { v4 as uuidv4 } from "uuid";
import Grid from "@material-ui/core/Grid";
import SpeedIcon from "@material-ui/icons/Speed";
// import IconButton from '@material-ui/core/IconButton'
import FilledInput from "@material-ui/core/FilledInput";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import BuildIcon from "@material-ui/icons/Build";
import useMediaQuery from "@material-ui/core/useMediaQuery";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from "@material-ui/pickers";

// import filledInput from '@material-ui/core/filledInput'
import Slider from "@material-ui/core/Slider";
import Input from "@material-ui/core/Input";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormLabel from "@material-ui/core/FormLabel";

import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import ListItemText from "@material-ui/core/ListItemText";
import PersonIcon from "@material-ui/icons/Person";
import AddIcon from "@material-ui/icons/Add";
import Avatar from "@material-ui/core/Avatar";
import Select from "@material-ui/core/Select";
import { spacing } from "@material-ui/system";
import InfoIcon from "@material-ui/icons/HelpOutlineOutlined";
import EditRoundedIcon from "@material-ui/icons/EditRounded";
import Tooltip from "@material-ui/core/Tooltip";
import Fade from "@material-ui/core/Fade";

import Backdrop from "@material-ui/core/Backdrop";

// import Button from "@material-ui/core/Button";
import ButtonGroup from "@material-ui/core/ButtonGroup";
import Container from "@material-ui/core/Container";
// import LuckyExcel from "luckyexcel";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import hip from "../../static/hip.png";
import gable from "../../static/gable.png";
import pyramid from "../../static/pyramid.png";
import labeled from "../../static/labeled.png";
import Axes01 from "../../static/Axes01.png";
import OverturnX01 from "../../static/OverturnX01.png";
import OverturnY01 from "../../static/OverturnY01.png";

import DialogContentText from "@material-ui/core/DialogContentText";

// import NativeSelect from '@material-ui/core/NativeSelect'

// import TextField from '@material-ui/core/TextField'
// import Visibility from '@material-ui/icons/Visibility'
// import VisibilityOff from '@material-ui/icons/VisibilityOff'

// import {
//   ACCOUNT_PATH,
//   LIST_PATH,
//   LOGIN_PATH,
//   SIGNUP_PATH,
//   FORM_PATH
// } from 'constants/paths'
import styles from "./Tools.styles";
import { withStyles } from "@material-ui/core/styles";
import { isGranted } from "../../config/auth";

const emails = ["Imperial System (ft)", "Metric System (m)"];
const useStyles = makeStyles(styles);

const loadData = async (path) => {
  const data = await fetch(path);
  const text = await data.text();
  return text;
};

const options = [
  "None",
  "Atria",
  "Callisto",
  "Dione",
  "Ganymede",
  "Hangouts Call",
  "Luna",
  "Oberon",
  "Phobos",
  "Pyxis",
  "Sedna",
  "Titania",
  "Triton",
  "Umbriel",
];

function ConfirmationDialogRaw(props) {
  const { onClose, value: valueProp, open, ...other } = props;
  const [value, setValue] = React.useState(valueProp);
  const radioGroupRef = React.useRef(null);

  React.useEffect(() => {
    if (!open) {
      setValue(valueProp);
    }
  }, [valueProp, open]);

  const handleEntering = () => {
    if (radioGroupRef.current != null) {
      radioGroupRef.current.focus();
    }
  };

  const handleCancel = () => {
    onClose();
  };

  const handleOk = () => {
    onClose(value);
  };

  const handleChange = (event) => {
    setValue(event.target.value);
  };

  return (
    <Dialog
      disableBackdropClick
      disableEscapeKeyDown
      maxWidth='xs'
      onEntering={handleEntering}
      aria-labelledby='confirmation-dialog-title'
      open={open}
      {...other}>
      <DialogTitle id='confirmation-dialog-title'>Phone Ringtone</DialogTitle>
      <DialogContent dividers>
        <RadioGroup
          ref={radioGroupRef}
          aria-label='ringtone'
          name='ringtone'
          value={value}
          onChange={handleChange}>
          {options.map((option) => (
            <FormControlLabel
              value={option}
              key={option}
              control={<Radio />}
              label={option}
            />
          ))}
        </RadioGroup>
      </DialogContent>
      <DialogActions>
        <Button autoFocus onClick={handleCancel} color='primary'>
          Cancel
        </Button>
        <Button onClick={handleOk} color='primary'>
          Ok
        </Button>
      </DialogActions>
    </Dialog>
  );
}

ConfirmationDialogRaw.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  value: PropTypes.string.isRequired,
};

const MarkdownPage = ({ path, pageProps }) => {
  const [source, setSource] = useState(null);

  useEffect(() => {
    loadData(path).then((text) => {
      setSource(text);
    });
  }, [path]);

  return (
    <Scrollbar>
      <div
        style={{
          backgroundColor: "white",
          position: "relative",
          margin: "0px auto",
          width: "100%",
          padding: 12,
        }}>
        {source && (
          <ReactMarkdown className='markdown-body' source={source} escapeHtml />
        )}
      </div>
    </Scrollbar>
  );
};

const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <Typography variant='h6'>{children}</Typography>
      {onClose ? (
        <IconButton
          aria-label='close'
          className={classes.closeButton}
          onClick={onClose}>
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
  root: {
    margin: 0,
    padding: theme.spacing(1),
  },
}))(MuiDialogActions);

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction='up' ref={ref} {...props} />;
});

const Tools = ({ intl }) => {
  const history = useHistory();
  const { firebaseApp } = useFirebase();

  const [open, setOpen] = useState(false);
  const [openOptions, setOOpen] = useState(false);
  const [loading, setLoading] = React.useState(false);

  const loadingClose = () => {
    setLoading(false);
  };
  const loadingToggle = () => {
    setLoading(!loading);
  };

  const [switchState, setSwitchState] = React.useState({
    checkedA: true,
    checkedB: true,
  });
  const handleSwitchChange = (event) => {
    setSwitchState({
      ...switchState,
      [event.target.name]: event.target.checked,
    });
  };
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const handleOptionsClickOpen = () => {
    setOptionsOpen(true);
  };
  const handleOptionsClose = () => {
    setOptionsOpen(false);
  };
  function SimpleDialog(props) {
    const classes = useStyles();
    const { onOClose, selectedOValue, openO } = props;

    const handleOClose = () => {
      onOClose(selectedOValue);
    };

    const handleListItemClick = (value) => {
      onOClose(value);
    };

    return (
      <Dialog
        onClose={handleOClose}
        aria-labelledby='simple-dialog-title'
        open={openO}>
        <DialogTitle id='simple-dialog-title'>Set backup account</DialogTitle>
        <List>
          {emails.map((email) => (
            <ListItem
              button
              onClick={() => handleListItemClick(email)}
              key={email}>
              <ListItemAvatar>
                <Avatar className={classes.avatar}>
                  <PersonIcon />
                </Avatar>
              </ListItemAvatar>
              <ListItemText primary={email} />
            </ListItem>
          ))}

          <ListItem
            autoFocus
            button
            onClick={() => handleListItemClick("addAccount")}>
            <ListItemAvatar>
              <Avatar>
                <AddIcon />
              </Avatar>
            </ListItemAvatar>
            <ListItemText primary='Add account' />
          </ListItem>
        </List>
      </Dialog>
    );
  }

  SimpleDialog.propTypes = {
    onOptionsClose: PropTypes.func.isRequired,
    openOptions: PropTypes.bool.isRequired,
    selectedOptionsValue: PropTypes.string.isRequired,
  };

  const FormDialogTitle = withStyles(styles)((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
      <MuiDialogTitle disableTypography className={classes.root} {...other}>
        <Typography variant='h6'>{children}</Typography>
        {onClose ? (
          <IconButton
            aria-label='close'
            className={classes.closeButton}
            onClick={onClose}>
            <CloseIcon />
          </IconButton>
        ) : null}
      </MuiDialogTitle>
    );
  });

  const FormDialogContent = withStyles((theme) => ({
    root: {
      padding: theme.spacing(2),
    },
  }))(MuiDialogContent);

  const FormDialogActions = withStyles((theme) => ({
    root: {
      margin: 0,
      padding: theme.spacing(1),
    },
  }))(MuiDialogActions);

  const [openForm, setFormOpen] = React.useState(false);

  const [getDialogVal, setDialogVal] = React.useState(1);
  function handleFormOpen() {
    console.log(getDialogVal);
    const post = findArrayElementByTitle(posts, getDialogVal);
    console.log(post);
    setResults({ title: post.title, content: post.content });
    setFormOpen(true);
  }

  function findArrayElementByTitle(array, id) {
    return array.find((element) => {
      return element.id === id;
    });
  }
  const handleFormClose = () => {
    setFormOpen(false);
  };
  const classes = useStyles();

  // const { register, handleSubmit, errors } = useForm()
  // const onSubmit = (data) => console.log(data)
  // console.log(errors)
  const [results, setResults] = useState({
    title: "",
    content: "",
  });

  function handleRadioChange() {
    console.log(getDialogVal);
    const post = findArrayElementByTitle(posts, getDialogVal);
    console.log(post);
    setResults({ title: post.title, content: post.content });
    setFormOpen(true);
  }
  const [optionsOpen, setOptionsOpen] = React.useState(false);
  const [selectedOptionsValue, setOptionsSelectedValue] = React.useState(
    emails[1]
  );

  const handleOClickOpen = () => {
    setOptionsOpen(true);
  };

  const handleOClose = (value) => {
    setOptionsOpen(false);
    setOptionsSelectedValue(value);
  };

  // 0 for imperial (feet), 1 for metric (meters)
  const [units, setUnits] = React.useState({
    unit: 0,

    size: ["ft", "m"],
    speed: ["mph", "kph"],
    weight: ["lbs", "kg"],
  });

  const [values, setValues] = useState({
    companyName: "",
    project: "",
    location: "",
    projectDate: new Date(),
    unit: 0,
    openFX: 0,
    openFY: 0,
    openFZ: 0,
    openOML: 0,
    openOMW: 0,
    partFX: 0,
    partFY: 0,
    partFZ: 0,
    partOML: 0,
    partOMW: 0,
    encFX: 0,
    encFY: 0,
    encFZ: 0,
    encOML: 0,
    encOMW: 0,
    windSpeed: 20,
    windFlow: 1,
    tentWidth: 20,
    tentLength: 40,
    eaveHeight: 8,
    bandHeight: 1,
    roofType: 1,
    ridgeLength: 6,
    roofHeight: 6,
    postsPerWidth: 1,
    postsPerLength: 1,
    ballastsPerIntermediate: 1,
    ballastsPerCornerPost: 1,
    totalBallasts: 0,
    openBallastWeight: 0,
    partBallastWeight: 0,
    encBallastWeight: 0,
    calcID: uuidv4(),
    title: "",
    time: 0,
    share: {},
    notes: "",
  });

  const handleChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  /* RENDER DATA TABLE */
  const [calculationDataOpen, setCalculationDataOpen] = useState(false);
  const showResults = (result) => {
    console.log(result);
    const vals = result.data;
    setValues(result.data);
    loadingClose();
    setCalculationDataOpen(true);
    ReactDOM.render(
      <Container className={classes.cardGrid}>
        <div style={{ height: 220 }}>
          <DataGrid
            columns={[
              { field: "id", hide: true },
              {
                field: "Enclosure",
                headerName: "Enclosure",
                type: "string",
                width: 150,
                resizable: true,
              },
              {
                field: "ballastWeight",
                headerName: "Ballast weight per leg/upright (lbs)",
                type: "number",

                resizable: true,
              },
              {
                field: "overturnMomentLength",
                headerName: "Overturn moment about length (lbs.ft)",
                type: "number",

                resizable: true,
              },
              {
                field: "overturnMomentWidth",
                headerName: "Overturn moment about width (lbs.ft)",
                type: "number",

                resizable: true,
              },
              {
                field: "FX",
                headerName: "Horizontal Force in Length (lbs)",
                type: "number",

                resizable: true,
              },
              {
                field: "FY",
                headerName: "Horizontal Force in Width (lbs)",
                type: "number",

                resizable: true,
              },
              {
                field: "FZ",
                headerName: "Vertical Uplift Force (lbs)",
                type: "number",

                resizable: true,
              },
            ]}
            rows={[
              {
                id: 1,
                Enclosure: "Open",
                overturnMomentLength: vals.openOML,
                overturnMomentWidth: vals.openOMW,
                FX: vals.openFX,
                FY: vals.openFY,
                FZ: vals.openFZ,
                ballastWeight: vals.openBallastWeight,
              },
              {
                id: 2,
                Enclosure: "Partially Enclosed",

                overturnMomentLength: vals.partOML,
                overturnMomentWidth: vals.partOMW,
                FX: vals.partFX,
                FY: vals.partFY,
                FZ: vals.partFZ,
                ballastWeight: vals.partBallastWeight,
              },
              {
                id: 3,
                Enclosure: "Enclosed",
                overturnMomentLength: vals.encOML,
                overturnMomentWidth: vals.encOMW,
                FX: vals.encFX,
                FY: vals.encFY,
                FZ: vals.encFZ,
                ballastWeight: vals.encBallastWeight,
              },
            ]}
            autoHeight={true}
            hideFooter={true}
            headerHeight={100}
            rowHeight={30}
            disableColumnMenu={true}
          />
        </div>
      </Container>,
      document.getElementById("calculationDataTable")
    );

    // if (result.data.windFlow === 1) {
    //   setResults({
    //     overturnMoment: result.data.openOM,
    //     verticalUpliftForce: result.data.openFZ,
    //   });
    // } else if (result.data.windFlow === 2) {
    //   setResults({
    //     overturnMoment: result.data.partOM,
    //     verticalUpliftForce: result.data.partFZ,
    //   });
    // } else {
    //   setResults({
    //     overturnMoment: result.data.encOM,
    //     verticalUpliftForce: result.data.encFZ,
    //   });
    // }

    //handleClickOpen();
  };

  const [value, setValue] = React.useState(10);

  const handleSliderChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleInputChange = (event) => {
    setValue(event.target.value === "" ? "" : Number(event.target.value));
  };

  const handleBlur = () => {
    if (value < 0) {
      setValue(0);
    } else if (value > 100) {
      setValue(100);
    }
  };
  const [dataGridContainer, setGridResults] = React.useState(<div></div>);
  const [btnDisabled, setBtnDisabled] = useState(true);
  const handleSelectChange = (event) => {
    const name = event.target.name;
    console.log(name);
    if (name === "roofType") {
      console.log("is roof change");
      console.log(event.target.value);
      if (event.target.value === "2") {
        setBtnDisabled(false);
        console.log("is hip");
      } else {
        setBtnDisabled(true);
      }
    }
    setValues({
      ...values,
      [name]: event.target.value,
    });
  };
  const posts = [
    {
      id: 1,
      title: "Wind speed",
      content: "Enter wind speed ",
    },
    {
      id: 2,
      title: "Wind flow",
      content:
        "Clear - unobstructed wind flow with no blockage (e.g., plain, grass land, beach). This is the worst case scenario.Partially obstructed - relatively unobstructed wind flow with blockage less than or equal to 50%. Obstructed - objects below roof inhibiting wind flow with >50% blockage (e.g., urban environment, high dense vegetation, high cliff)",
    },
    {
      id: 3,
      title: "Tent width (feet)",
      content:
        "Dimension perpendicular to ridge. Also, the width defines the Y-axis.",
    },
    {
      id: 4,
      title: "Tent length (feet)",
      content:
        "Dimension parallel to ridge. Also, the length defines the X-axis.",
    },
    {
      id: 5,
      title: "Heave height (feet)",
      content:
        "Vertical distance between the ground of the lowest part of the roof. The band is neglected.",
    },
    {
      id: 6,
      title: "Roof type",
      content: "Three options: Gable, Hip, Pyramid",
    },
    {
      id: 7,
      title: "Ridge length (feet)",
      content: "Define ridge length only if Hip roof is selected",
    },
    {
      id: 8,
      title: "Roof height (feet)",
      content:
        "Vertical distance between the lowest part of the roof (top of posts) and the highest part of the roof.",
    },
    {
      id: 9,
      title: "Number of intermediate posts in length",
      content:
        "Number of intermediate posts in length (Excluding corner posts)",
    },
    {
      id: 10,
      title: "Number of intermediate posts in width",
      content: "Number of intermediate posts in width (Excluding corner posts)",
    },
    {
      id: 11,
      title: "Number of Ballasts Per Corner Post",
      content: "The total number of ballasts per corner post",
    },
  ];
  const [dialogResults, setResultsDialogResults] = useState({
    title: "",
    content: "",
  });
  function startCloudFunc() {
    loadingToggle();
    const httpsCalculationOnCall = firebaseApp
      .functions()
      .httpsCallable("httpsCalculationOnCall");
    // Add a new document in collection "cities"

    httpsCalculationOnCall({ values })
      .then((result) => {
        // Read result of the Cloud Function.
        console.log(values.calcID);
        showResults(result);
        // firebaseApp
        //   .firestore()
        //   .collection("members")
        //   .doc(firebaseApp.auth().currentUser.uid)
        //   .collection("saved")
        //   .doc(values.calcID)
        //   .onSnapshot(
        //     function (snapshot) {
        //       console.log(snapshot.data());
        //       // showResults(snapshot.data());
        //       return snapshot.data();
        //     },
        //     function (error) {
        //       console.log(error);
        //       return;
        //     }
        //   );
      })
      .catch((error) => {
        // Getting the Error details.
        var code = error.code;
        var message = error.message;
        var details = error.details;
        console.log(error);
        // ...
      });
    console.log("Document successfully written!");
  }

  const [resultValuesGrid, setValuesGrid] = React.useState([]);

  const tileData = [
    {
      img: labeled,
      title: "Input Variables",
      author: "",
      featured: true,
    },
    {
      img: Axes01,
      title: "Axes",
      author: "author",
      featured: false,
    },
    {
      img: OverturnX01,
      title: "Overturn about X-Axis",
      author: "author",
      featured: false,
    },
    {
      img: OverturnY01,
      title: "Overturn about Y-Axis",
      author: "author",
      featured: false,
    },
    {
      img: pyramid,
      title: "Pyramid Roof",
      author: "author",
      featured: false,
    },
    {
      img: hip,
      title: "Hip Roof",
      author: "author",
      featured: false,
    },
    {
      img: gable,
      title: "Gable Roof",
      author: "author",
      featured: false,
    },
  ];
  const { auth } = useAuth();
  // console.log(auth);
  // console.log(isGranted(auth, "member"));
  return isGranted(auth, "member") ? (
    <Page
      pageTitle={intl.formatMessage({
        id: "tools",
        defaultMessage: "IFAI Ballast Tool",
      })}>
      <div className={classes.root}>
        <Backdrop
          className={classes.backdrop}
          open={loading}
          onClick={loadingClose}>
          <CircularProgress color='inherit' />
        </Backdrop>
        <Dialog
          onClose={handleFormClose}
          aria-labelledby='customized-dialog-title'
          open={openForm}>
          <FormDialogTitle
            id='customized-dialog-title'
            onClose={handleFormClose}>
            {results.title}
          </FormDialogTitle>
          <FormDialogContent dividers>
            <Typography gutterBottom>{results.content}</Typography>
          </FormDialogContent>
          <FormDialogActions>
            <Button autoFocus onClick={handleFormClose} color='primary'>
              Ok
            </Button>
          </FormDialogActions>
        </Dialog>

        <div className={classes.fab}>
          <Fab
            variant='extended'
            onClick={async () => {
              // const handleClickOpen = () => {
              //   setOpen(true);
              // };

              //startCloudFunc();
              setOpen(true);
              // setLoading(true);
              //history.push("/about");
            }}
            size='large'
            color='primary'
            aria-label='Help'
            className={classes.margin}>
            <EditRoundedIcon className={classes.extendedIcon} />
            Help
          </Fab>
        </div>

        {/* Popup for results of the calculation */}
        <div>
          <Dialog
            fullScreen
            TransitionComponent={Transition}
            onClose={handleClose}
            aria-labelledby='customized-dialog-title'
            open={open}>
            {/* <DialogTitle id='customized-dialog-title' onClose={handleClose}>
              More Info
            </DialogTitle> */}
            <DialogContent>
              <MarkdownPage
                pageProps={{
                  pageTitle: intl.formatMessage({
                    id: "about",
                    defaultMessage: "About",
                  }),
                }}
                path={
                  "https://raw.githubusercontent.com/henryhawke/ballastpublic/main/README.md"
                }
              />
              {/* <Typography variant='h4' gutterBottom>
                Overturn moment = {results.overturnMoment} {units.weight[units.unit]}.{units.size[units.unit]}
              </Typography>
              <Typography variant='h4' gutterBottom>
                Vertical uplift force per guy = {results.verticalUpliftForce}{" "}
                lbs
              </Typography> */}
              {/* <Typography gutterBottom>
                Praesent commodo cursus magna, vel scelerisque nisl consectetur
                et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus
                dolor auctor.
              </Typography>
              <Typography gutterBottom>
                Aenean lacinia bibendum nulla sed consectetur. Praesent commodo
                cursus magna, vel scelerisque nisl consectetur et. Donec sed
                odio dui. Donec ullamcorper nulla non metus auctor fringilla.
              </Typography> */}
            </DialogContent>
            <DialogActions>
              <Button autoFocus onClick={handleClose} color='primary'>
                Save changes
              </Button>
            </DialogActions>
          </Dialog>
        </div>

        <div className={classes.root}>
          {/* Calculations Results Table */}
          <Grid container spacing={1}>
            <Grid
              item
              xs={12}
              sm={12}
              style={{
                display: { calculationDataOpen } ? "inherit" : "none",
              }}
              id='calculationDataTable'></Grid>
          </Grid>
          {/* Form */}
          <Grid item xs={12} sm={6}>
            {/* FORM */}
            <Container className={classes.cardGrid}>
              <form className={classes.root}>
                <Grid
                  container
                  direction='row'
                  justify='flex-start'
                  alignItems='center'
                  spacing={3}>
                  {/* UNITS */}
                  <Grid item xs={6}>
                    <FormControl
                      component='fieldset'
                      // error={error}
                      className={classes.formControl}>
                      <FormLabel component='legend'>Units</FormLabel>
                      <RadioGroup
                        aria-label='quiz'
                        name='quiz'
                        value={value}
                        onChange={handleRadioChange}>
                        <FormControlLabel
                          value='0'
                          control={<Radio />}
                          label='Imperial System (ft)'
                        />
                        <FormControlLabel
                          value='1'
                          control={<Radio />}
                          label='Metric System (m)'
                        />
                      </RadioGroup>
                    </FormControl>
                  </Grid>

                  {/* DOWNLOAD PRINTABLE */}
                  <Grid item xs={6}>
                    <FormControl
                      component='fieldset'
                      // error={error}
                      className={classes.formControl}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={switchState.checkedA}
                            onChange={handleChange}
                            name='checkedA'
                          />
                        }
                        label='Generate Calculations PDF'
                      />
                      {/* <FormControlLabel
                        control={
                          <Switch
                            checked={switchState.checkedB}
                            onChange={handleChange}
                            name='checkedB'
                            color='primary'
                          />
                        }
                        label='Primary'
                      /> */}
                      {/* <FormControlLabel
                        control={<Switch />}
                        label='Uncontrolled'
                      />
                      <FormControlLabel
                        disabled
                        control={<Switch />}
                        label='Disabled'
                      />
                      <FormControlLabel
                        disabled
                        control={<Switch checked />}
                        label='Disabled'
                      /> */}
                    </FormControl>
                  </Grid>
                  {/* Title */}
                  <Grid item xs={12}>
                    {/* Title */}
                    <FormControl
                      className={clsx(classes.textField)}
                      variant='outlined'>
                      <InputLabel htmlFor='outlined-age-native-simple'>
                        Calculation Title
                      </InputLabel>
                      <OutlinedInput
                        id='outlined-adornment-weight'
                        value={values.title}
                        label='Calculation Title'
                        placeholder='Calculation Title'
                        onChange={handleChange("title")}
                        aria-describedby='outlined-weight-helper-text'
                        inputProps={{
                          name: "title",
                          "aria-label": "weight",
                        }}
                      />
                    </FormControl>
                  </Grid>

                  {/* NOTES */}
                  {/* <Grid item sm={12} md={6}>
                      {" "}
                      <FormControl
                        fullWidth
                        className={classes.textField}
                        variant='outlined'>
                        <InputLabel htmlFor='outlined-adornment-amount'>
                          Notes
                        </InputLabel>
                        <filledInput
                          label='Notes'
                          id='outlined-adornment-weight'
                          value={values.notes}
                          onChange={handleChange("notes")}
                          rows={4}
                          multiline
                        />
                      </FormControl>
                    </Grid> */}
                </Grid>
                {/* Company Name */}
                <Grid item xs={6}>
                  {/* Company Name */}
                  <FormControl
                    className={clsx(classes.textField)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Company Name
                    </InputLabel>
                    <OutlinedInput
                      id='outlined-adornment-weight'
                      value={values.companyName}
                      label='Company Name'
                      placeholder='Company Name'
                      onChange={handleChange("companyName")}
                      aria-describedby='outlined-weight-helper-text'
                      inputProps={{
                        name: "title",
                        "aria-label": "weight",
                      }}
                    />
                  </FormControl>
                </Grid>
                {/* Project */}
                <Grid item xs={6}>
                  {/* Project */}
                  <FormControl
                    className={clsx(classes.textField)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Project
                    </InputLabel>
                    <OutlinedInput
                      id='outlined-adornment-weight'
                      value={values.project}
                      label='Project'
                      placeholder='Project'
                      onChange={handleChange("project")}
                      aria-describedby='outlined-weight-helper-text'
                      inputProps={{
                        name: "project",
                        "aria-label": "weight",
                      }}
                    />
                  </FormControl>
                </Grid>
                {/* Location */}
                <Grid item xs={6}>
                  {/* Location */}
                  <FormControl
                    className={clsx(classes.textField)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Location
                    </InputLabel>
                    <OutlinedInput
                      id='outlined-adornment-weight'
                      value={values.location}
                      label='Location'
                      placeholder='Location'
                      onChange={handleChange("location")}
                      aria-describedby='outlined-weight-helper-text'
                      inputProps={{
                        name: "location",
                        "aria-label": "weight",
                      }}
                    />
                  </FormControl>
                </Grid>
                {/* Project Date */}
                <Grid item xs={6}>
                  {/* Project Date */}
                  <FormControl
                    className={clsx(classes.textField)}
                    variant='outlined'>
                    <TextField
                      id='date'
                      label='Project Date'
                      type='date'
                      value={values.projectDate}
                      onChange={handleChange("projectDate")}
                      defaultValue={format(new Date(), "yyyy-mmmm-Do")}
                      className={classes.textField}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </FormControl>
                </Grid>

                {/* NOTES */}
                {/* Wind Speed */}
                <Grid item xs={6}>
                  <Tooltip
                    title='Maximum Wind Speed expected while tent is setup'
                    interactive
                    className={clsx(classes.tooltip)}
                    enterDelay={400}
                    leaveDelay={300}
                    TransitionComponent={Fade}
                    TransitionProps={{ timeout: 600 }}
                    arrow>
                    <FormControl
                      className={clsx(classes.formControl)}
                      variant='outlined'>
                      <InputLabel htmlFor='outlined-age-native-simple'>
                        Wind Speed ({units.speed[units.unit]})
                      </InputLabel>
                      <Select
                        native
                        endAdornment={
                          <InputAdornment position='end'>
                            <EditRoundedIcon
                              onClick={() => {
                                setDialogVal(1);
                                handleFormOpen();
                              }}
                            />
                          </InputAdornment>
                        }
                        defaultValue={20}
                        label='Wind Speed ({units.speed[units.unit]})'
                        value={value.windSpeed}
                        onChange={handleSelectChange}
                        inputProps={{
                          name: "windSpeed",
                          id: "outlined-age-native-simple",
                        }}>
                        <option value={10}>10</option>
                        <option value={20}>20</option>
                        <option value={30}>30</option>
                        <option value={40}>40</option>
                        <option value={50}>50</option>
                        <option value={60}>60</option>
                        <option value={70}>70</option>
                        <option value={80}>80</option>
                        <option value={90}>90</option>
                        <option value={100}>100</option>
                        <option value={110}>110</option>
                        <option value={120}>120</option>
                        <option value={130}>130</option>
                        <option value={140}>140</option>
                        <option value={150}>150</option>
                      </Select>
                    </FormControl>
                  </Tooltip>
                </Grid>
                {/* Wind Flow */}
                <Grid item xs={6}>
                  <FormControl
                    variant='outlined'
                    className={classes.formControl}>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Wind Flow
                    </InputLabel>
                    <Select
                      native
                      defaultValue={1}
                      label='Wind Flow'
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(2);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      value={value.windFlow}
                      onChange={handleSelectChange}
                      inputProps={{
                        name: "windFlow",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={1}>Clear</option>
                      <option value={2}>Semi-Obstructed</option>
                      <option value={3}>Obstructed</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Tent Width */}
                <Grid item xs={6}>
                  {/* Tent Width */}
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Tent Width ({units.size[units.unit]})
                    </InputLabel>
                    <Select
                      native
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(3);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      defaultValue={20}
                      label='Tent Width'
                      value={value.tentWidth}
                      onChange={handleSelectChange}
                      inputProps={{
                        name: "tentWidth",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={10}>10</option>
                      <option value={15}>15</option>
                      <option value={20}>20</option>
                      <option value={30}>30</option>
                      <option value={40}>40</option>
                      <option value={50}>50</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Tent Length */}
                <Grid item xs={6}>
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Tent Length ({units.size[units.unit]})
                    </InputLabel>
                    <Select
                      native
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(4);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      defaultValue={40}
                      label='Tent Length'
                      value={value.tentLength}
                      onChange={handleSelectChange}
                      inputProps={{
                        name: "tentLength",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={10}>10</option>
                      <option value={15}>15</option>
                      <option value={20}>20</option>
                      <option value={30}>30</option>
                      <option value={40}>40</option>
                      <option value={50}>50</option>
                      <option value={60}>60</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Eave Height */}

                <Grid item xs={6}>
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    {/* Eave Height */}
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Eave Height ({units.size[units.unit]})
                    </InputLabel>
                    <Select
                      native
                      defaultValue={7}
                      label='Eave Height'
                      value={value.eaveHeight}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(5);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "eaveHeight",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={7}>7</option>
                      <option value={8}>8</option>
                      <option value={9}>9</option>
                      <option value={10}>10</option>
                    </Select>
                  </FormControl>
                </Grid>

                {/* Roof Type */}
                <Grid item xs={6}>
                  {/* Roof Type */}
                  <FormControl
                    variant='outlined'
                    className={classes.formControl}>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Roof Type
                    </InputLabel>
                    <Select
                      native
                      label='Roof Type'
                      defaultValue={1}
                      value={value.roofType}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(6);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "roofType",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={1}>Gable</option>
                      <option value={2}>Hip</option>
                      <option value={3}>Pyramid</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Ridge Length */}
                <Grid item xs={6}>
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Ridge Length ({units.size[units.unit]})
                    </InputLabel>
                    <Select
                      native
                      defaultValue={5}
                      label='Ridge Length'
                      value={value.ridgeLength}
                      disabled={btnDisabled}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(7);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "ridgeLength",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={5}>5</option>
                      <option value={10}>10</option>
                      <option value={15}>15</option>
                      <option value={20}>20</option>
                      <option value={25}>25</option>
                      <option value={30}>30</option>
                      <option value={35}>35</option>
                      <option value={40}>40</option>
                      <option value={45}>45</option>
                      <option value={50}>50</option>
                      <option value={55}>55</option>
                      <option value={60}>60</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Roof Height */}

                <Grid item xs={6}>
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Roof Height ({units.size[units.unit]})
                    </InputLabel>
                    <Select
                      native
                      defaultValue={5}
                      label='Roof Height '
                      value={value.roofHeight}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(8);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "roofHeight",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={5}>5</option>
                      <option value={10}>10</option>
                      <option value={15}>15</option>
                      <option value={20}>20</option>
                      <option value={25}>25</option>
                      <option value={30}>30</option>
                      <option value={35}>35</option>
                      <option value={40}>40</option>
                      <option value={45}>45</option>
                      <option value={50}>50</option>
                      <option value={55}>55</option>
                      <option value={60}>60</option>
                    </Select>
                  </FormControl>
                </Grid>

                {/* Posts In Length */}
                <Grid item xs={6}>
                  {/* Posts Per Length */}
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      Intermediate posts in length
                    </InputLabel>
                    <Select
                      native
                      defaultValue={3}
                      label='# intermediate posts in length (Including Corner Posts)'
                      value={value.postsPerLength}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(9);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "postsPerLength",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                      <option value={4}>4</option>
                      <option value={5}>5</option>
                      <option value={6}>6</option>
                      <option value={7}>7</option>
                      <option value={8}>8</option>
                      <option value={9}>9</option>
                      <option value={10}>10</option>
                      <option value={11}>11</option>
                      <option value={12}>12</option>
                      <option value={13}>13</option>
                      <option value={14}>14</option>
                      <option value={15}>15</option>
                    </Select>
                  </FormControl>
                </Grid>

                {/* Posts in Width */}
                <Grid item xs={6}>
                  {/* Posts Per Width */}
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      # intermediate posts in width
                    </InputLabel>
                    <Select
                      native
                      defaultValue={3}
                      label='# intermediate posts in width (Including Corner Posts)'
                      value={value.postsPerWidth}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(10);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "postsPerWidth",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                      <option value={4}>4</option>
                      <option value={5}>5</option>
                      <option value={6}>6</option>
                      <option value={7}>7</option>
                      <option value={8}>8</option>
                      <option value={9}>9</option>
                      <option value={10}>10</option>
                      <option value={11}>11</option>
                      <option value={12}>12</option>
                      <option value={13}>13</option>
                      <option value={14}>14</option>
                      <option value={15}>15</option>
                    </Select>
                  </FormControl>
                </Grid>
                {/* Ballasts Per Corner */}
                <Grid item xs={6}>
                  {/* ballastsPerCornerPost */}
                  <FormControl
                    className={clsx(classes.formControl)}
                    variant='outlined'>
                    <InputLabel htmlFor='outlined-age-native-simple'>
                      # ballasts per corner post
                    </InputLabel>
                    <Select
                      native
                      defaultValue={1}
                      label='# ballasts per corner post'
                      value={value.ballastsPerCornerPost}
                      onChange={handleSelectChange}
                      endAdornment={
                        <InputAdornment position='end'>
                          <EditRoundedIcon
                            onClick={() => {
                              setDialogVal(11);
                              handleFormOpen();
                            }}
                          />
                        </InputAdornment>
                      }
                      inputProps={{
                        name: "ballastsPerCornerPost",
                        id: "outlined-age-native-simple",
                      }}>
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={6}>
                  <FormControl
                    component='fieldset'
                    // error={error}
                    className={classes.formControl}>
                    {/* <FormHelperText>{helperText}</FormHelperText> */}
                    <ButtonGroup
                      className={clsx(classes.calculateButton)}
                      variant='contained'
                      color='primary'
                      fullWidth={true}
                      aria-label='contained primary button group'>
                      {/* <Button
                        variant='outlined'
                        color='primary'
                        onClick={handleOptionsClickOpen}>
                        Options
                      </Button> */}
                      <SimpleDialog
                        selectedOptionsValue={selectedOptionsValue}
                        openOptions={optionsOpen}
                        onOptionsClose={handleOptionsClose}
                      />
                      <Button
                        onClick={() => {
                          startCloudFunc();
                          // handleFormOpen();
                        }}>
                        Calculate
                      </Button>
                      {/* <Button>Save</Button> */}
                    </ButtonGroup>
                  </FormControl>
                </Grid>
              </form>

              {/* End hero unit */}
            </Container>
          </Grid>
          {/* Infograph */}
          <Grid item sm={12} md={6}>
            {/* {" "}
              <Paper className={classes.mainFeaturedPost}>
                <div className={classes.overlay} />
                <Grid container>
                  <Grid item md={5}>
                    <div className={classes.mainFeaturedPostContent}>
                      <Typography
                        component='h2'
                        variant='h4'
                        color='inherit'
                        styles={{ textShadow: "2px 2px 5px black" }}
                        gutterBottom>
                        Calculation of overturn moment due to horizontal wind
                      </Typography>
                      <Typography variant='h5' color='inherit' paragraph>
                        This tool calculates the load at each guy to resist
                        overturn due to horizontal wind force
                      </Typography>
                    </div>
                  </Grid>
                </Grid>
              </Paper> */}
            <div className={classes.gridRoot}>
              <GridList
                cellHeight={200}
                spacing={1}
                className={classes.gridImageList}>
                {tileData.map((tile) => (
                  <GridListTile
                    key={tile.img}
                    cols={tile.featured ? 2 : 1}
                    rows={tile.featured ? 2 : 1}>
                    <img
                      src={tile.img}
                      class={classes.tileImage}
                      alt={tile.title}
                    />
                    <GridListTileBar
                      title={tile.title}
                      titlePosition='top'
                      // actionIcon={
                      //   <IconButton
                      //     aria-label={`star ${tile.title}`}
                      //     className={classes.icon}>
                      //     <EditRoundedIcon />
                      //   </IconButton>
                      // }
                      actionPosition='left'
                      className={classes.titleImageBar}
                    />
                  </GridListTile>
                ))}
              </GridList>
            </div>
          </Grid>
        </div>
      </div>
    </Page>
  ) : (
    <Page
      pageTitle={intl.formatMessage({
        id: "tools",
        defaultMessage: "IFAI Ballast Tool",
      })}>
      <Typography variant='h6'>
        Account Membership Required for Full Access. Please contact support for
        access.
      </Typography>
    </Page>
  );
};

export default injectIntl(Tools);
